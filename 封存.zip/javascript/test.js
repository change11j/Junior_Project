function myFunction() {
    var timeoutID = window.setInterval(() => meritAmt.innerHTML-=3, 1000);
}
myFunction();
var timeId = window.setInterval(() => meritAmt.innerHTML -= 3, 30000);
